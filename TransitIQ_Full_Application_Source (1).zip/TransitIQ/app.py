from flask import Flask, render_template, request, jsonify
from pathlib import Path
import sqlite3
from datetime import datetime, timezone
from routing import plan_journey, simulate_delay, STOPS, BUS_ARRIVALS, ACCESSIBILITY

BASE_DIR = Path(__file__).resolve().parent
DB_PATH = BASE_DIR / "transitiq.db"

app = Flask(__name__)

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    with get_db() as conn:
        conn.execute("""
            CREATE TABLE IF NOT EXISTS crowd_reports (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                bus_id TEXT NOT NULL,
                crowd_level TEXT NOT NULL,
                note TEXT DEFAULT '',
                created_at TEXT NOT NULL
            )
        """)
        conn.execute("""
            CREATE TABLE IF NOT EXISTS notifications (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL,
                message TEXT NOT NULL,
                created_at TEXT NOT NULL,
                is_read INTEGER DEFAULT 0
            )
        """)

def save_notification(title, message):
    with get_db() as conn:
        conn.execute(
            "INSERT INTO notifications (title, message, created_at) VALUES (?, ?, ?)",
            (title, message, datetime.now(timezone.utc).isoformat())
        )

@app.route("/")
def home():
    return render_template("index.html")

@app.get("/api/stops")
def stops():
    return jsonify(STOPS)

@app.post("/api/plan")
def plan():
    data = request.get_json(silent=True) or {}
    origin = data.get("origin")
    destination = data.get("destination")
    if not origin or not destination:
        return jsonify({"error": "Choose both a starting point and destination."}), 400
    if origin == destination:
        return jsonify({"error": "Starting point and destination must be different."}), 400
    try:
        result = plan_journey(origin, destination, accessible_only=bool(data.get("accessible_only")))
        return jsonify(result)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

@app.post("/api/simulate-delay")
def delay():
    data = request.get_json(silent=True) or {}
    origin = data.get("origin", "Central Station")
    destination = data.get("destination", "City Hospital")
    try:
        result = simulate_delay(origin, destination)
        save_notification(
            "Connection at risk",
            "Bus 1 is simulated as 12 minutes late. Your planned connection may be missed. An alternative route is available."
        )
        return jsonify(result)
    except ValueError as exc:
        return jsonify({"error": str(exc)}), 400

@app.get("/api/buses")
def buses():
    return jsonify({
        "items": BUS_ARRIVALS,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "data_label": "Sample demonstration data"
    })

@app.get("/api/accessibility")
def accessibility():
    return jsonify(ACCESSIBILITY)

@app.post("/api/crowd")
def crowd_report():
    data = request.get_json(silent=True) or {}
    bus_id = (data.get("bus_id") or "").strip()
    level = data.get("crowd_level")
    note = (data.get("note") or "").strip()[:250]
    if not bus_id or level not in {"Low", "Moderate", "High"}:
        return jsonify({"error": "Select a bus and a valid crowd level."}), 400
    created = datetime.now(timezone.utc).isoformat()
    with get_db() as conn:
        conn.execute(
            "INSERT INTO crowd_reports (bus_id, crowd_level, note, created_at) VALUES (?, ?, ?, ?)",
            (bus_id, level, note, created)
        )
    return jsonify({"message": "Crowd report submitted. Thank you!", "created_at": created})

@app.get("/api/crowd")
def get_crowd_reports():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT bus_id, crowd_level, note, created_at FROM crowd_reports ORDER BY id DESC LIMIT 20"
        ).fetchall()
    return jsonify([dict(row) for row in rows])

@app.get("/api/notifications")
def notifications():
    with get_db() as conn:
        rows = conn.execute(
            "SELECT id, title, message, created_at, is_read FROM notifications ORDER BY id DESC LIMIT 20"
        ).fetchall()
    return jsonify([dict(row) for row in rows])

@app.post("/api/notifications/read")
def mark_notifications_read():
    with get_db() as conn:
        conn.execute("UPDATE notifications SET is_read = 1")
    return jsonify({"message": "Notifications marked as read."})

if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=5000, debug=True)
