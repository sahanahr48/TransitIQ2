# TransitIQ — Smart Public Transport Assistant

TransitIQ is a mobile-friendly Progressive Web App (PWA) with a Python Flask API and SQLite database.

## Features implemented

- **Journey planning:** choose a start and destination from the sample bus-stop network.
- **Dijkstra route calculation:** computes the lowest-travel-time path in the sample network.
- **Delay alert simulation:** reproduces the PDF example: Bus 1 is due at 08:10, arrives at 08:22 (12 minutes late), and the 08:15 connection is missed.
- **Alternative route and journey comparison:** shows travel time and number of transfers. In the PDF example, the delayed original route is 48 minutes and the alternative is 41 minutes.
- **Bus arrival information:** estimated minutes and a last-updated timestamp.
- **Crowd reporting:** Low / Moderate / High reports are saved in SQLite.
- **Accessibility information:** sample wheelchair, step-free and audio-information fields.
- **Notifications:** in-app notification list; delay simulation creates a notification.
- **PWA basics:** manifest and service worker for installability and basic static-file caching.

## Run on your computer

1. Install Python 3.10 or newer.
2. Extract this project folder.
3. Open a terminal inside the folder.
4. Create and activate a virtual environment (recommended):

   Windows:
   ```bash
   py -m venv venv
   venv\Scripts\activate
   ```

   macOS/Linux:
   ```bash
   python3 -m venv venv
   source venv/bin/activate
   ```

5. Install packages:
   ```bash
   pip install -r requirements.txt
   ```
6. Start the app:
   ```bash
   python app.py
   ```
7. Open `http://127.0.0.1:5000` in your browser.

The SQLite database is created automatically on first run.

## Put the code on GitHub

1. Create a new GitHub repository named `transitiq`.
2. Upload the contents of this folder (not the ZIP file itself).
3. Commit the files to the `main` branch.

## Important: GitHub hosting

GitHub stores your source code. **GitHub Pages only hosts static websites; it cannot run this Flask server or SQLite database.** To run this complete application online, keep the code in GitHub and deploy the Flask app to a Python hosting service that supports Flask. Set the service's start command to:

```bash
gunicorn app:app
```

For that deployment, add `gunicorn` to `requirements.txt`. Use a persistent disk for SQLite if the hosting provider's filesystem is temporary. Alternatively, use a hosted database for production.

## About the data

This project currently uses a small illustrative bus network and sample arrival estimates because the PDF does not provide a real transit feed, live GPS source, or official accessibility dataset. The map uses illustrative stop coordinates around Bengaluru. The app does **not** track real buses or send push notifications to a phone. Notifications are stored and displayed inside the app.

To make this a real city deployment, replace the sample data in `routing.py` with verified bus stops, routes, schedules, live vehicle positions or GTFS/GTFS-Realtime data, and verified accessibility information. The Dijkstra implementation is in `routing.py`.
