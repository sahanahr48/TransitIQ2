"""Sample transport network and Dijkstra route calculation for TransitIQ."""

import heapq
from copy import deepcopy

STOPS = [
    {"id": "central", "name": "Central Station"},
    {"id": "interchange", "name": "Interchange"},
    {"id": "market", "name": "Market Square"},
    {"id": "hospital", "name": "City Hospital"},
    {"id": "college", "name": "College Road"},
]

# Each directed edge represents one bus leg. Times are illustrative minutes.
EDGES = [
    {"from": "Central Station", "to": "Interchange", "minutes": 20, "bus": "Bus 1", "accessible": True},
    {"from": "Interchange", "to": "City Hospital", "minutes": 16, "bus": "Bus 2", "accessible": True},
    {"from": "Central Station", "to": "Market Square", "minutes": 18, "bus": "Bus C", "accessible": True},
    {"from": "Market Square", "to": "City Hospital", "minutes": 23, "bus": "Bus D", "accessible": False},
    {"from": "Central Station", "to": "College Road", "minutes": 12, "bus": "Bus 3", "accessible": True},
    {"from": "College Road", "to": "City Hospital", "minutes": 34, "bus": "Bus 4", "accessible": True},
    {"from": "Interchange", "to": "Market Square", "minutes": 9, "bus": "Bus 5", "accessible": True},
    {"from": "Market Square", "to": "College Road", "minutes": 14, "bus": "Bus 6", "accessible": True},
]

BUS_ARRIVALS = [
    {"bus_id": "Bus 1", "destination": "Interchange", "arrival_in": 4, "status": "On time"},
    {"bus_id": "Bus 2", "destination": "City Hospital", "arrival_in": 9, "status": "On time"},
    {"bus_id": "Bus C", "destination": "Market Square", "arrival_in": 6, "status": "On time"},
    {"bus_id": "Bus D", "destination": "City Hospital", "arrival_in": 15, "status": "On time"},
]

ACCESSIBILITY = [
    {"route": "Bus 1", "wheelchair": True, "step_free": True, "audio_info": True, "notes": "Low-floor bus and step-free boarding listed in sample data."},
    {"route": "Bus 2", "wheelchair": True, "step_free": True, "audio_info": False, "notes": "Step-free boarding listed; audio announcements not confirmed."},
    {"route": "Bus C", "wheelchair": True, "step_free": True, "audio_info": True, "notes": "Accessibility features listed in sample data."},
    {"route": "Bus D", "wheelchair": False, "step_free": False, "audio_info": False, "notes": "Not marked as accessible in the sample dataset."},
]

def _dijkstra(origin, destination, edges, accessible_only=False):
    graph = {}
    for edge in edges:
        if accessible_only and not edge["accessible"]:
            continue
        graph.setdefault(edge["from"], []).append(edge)

    # Dijkstra's algorithm: shortest total travel time from origin to destination.
    counter = 0
    queue = [(0, counter, origin, [])]
    best = {origin: 0}
    while queue:
        minutes, _, stop, path = heapq.heappop(queue)
        if minutes != best.get(stop):
            continue
        if stop == destination:
            return {"minutes": minutes, "transfers": max(0, len(path) - 1), "legs": path}
        for edge in graph.get(stop, []):
            next_stop = edge["to"]
            next_minutes = minutes + edge["minutes"]
            if next_minutes < best.get(next_stop, float("inf")):
                best[next_stop] = next_minutes
                counter += 1
                leg = {
                    "from": edge["from"], "to": edge["to"],
                    "bus": edge["bus"], "minutes": edge["minutes"],
                    "accessible": edge["accessible"]
                }
                heapq.heappush(queue, (next_minutes, counter, next_stop, path + [leg]))
    return None

def _route_summary(route, label):
    if not route:
        return None
    return {
        "label": label,
        "minutes": route["minutes"],
        "transfers": max(0, len(route["legs"]) - 1),
        "legs": route["legs"],
        "stops": [route["legs"][0]["from"]] + [leg["to"] for leg in route["legs"]]
    }

def plan_journey(origin, destination, accessible_only=False):
    names = {s["name"] for s in STOPS}
    if origin not in names or destination not in names:
        raise ValueError("Please choose a stop from the available list.")
    route = _dijkstra(origin, destination, EDGES, accessible_only=accessible_only)
    if not route:
        raise ValueError("No route is available between these stops in the sample network.")
    return {
        "origin": origin,
        "destination": destination,
        "recommended": _route_summary(route, "Fastest available route"),
        "alternatives": [],
        "warning": None,
        "data_label": "Sample demonstration data"
    }

def simulate_delay(origin, destination):
    """Demonstrates the PDF's 08:10 / 08:22 missed-connection scenario."""
    base = plan_journey(origin, destination)
    if origin == "Central Station" and destination == "City Hospital":
        original = {
            "minutes": 48, "transfers": 1,
            "legs": [
                {"from": "Central Station", "to": "Interchange", "bus": "Bus 1", "minutes": 20, "accessible": True},
                {"from": "Interchange", "to": "City Hospital", "bus": "Bus 2", "minutes": 16, "accessible": True}
            ],
            "stops": ["Central Station", "Interchange", "City Hospital"]
        }
        alternative = {
            "minutes": 41, "transfers": 1,
            "legs": [
                {"from": "Central Station", "to": "Market Square", "bus": "Bus C", "minutes": 18, "accessible": True},
                {"from": "Market Square", "to": "City Hospital", "bus": "Bus D", "minutes": 23, "accessible": False}
            ],
            "stops": ["Central Station", "Market Square", "City Hospital"]
        }
        return {
            "origin": origin, "destination": destination,
            "original": _route_summary(original, "Original route (delayed)"),
            "recommended": _route_summary(alternative, "Alternative route"),
            "warning": {
                "title": "Connection at risk",
                "message": "Bus 1 was due at Interchange at 08:10 but is simulated to arrive at 08:22. Bus 2 departs at 08:15, so the connection is missed.",
                "delay_minutes": 12,
                "scheduled_arrival": "08:10",
                "estimated_arrival": "08:22",
                "connecting_departure": "08:15"
            },
            "time_saved": 7,
            "data_label": "Illustrative simulation based on the PDF example"
        }

    # For other selected stops, calculate a route and report a generic simulation.
    recommended = base["recommended"]
    delayed = deepcopy(recommended)
    delayed["label"] = "Original route (simulated delay)"
    delayed["minutes"] += 12
    alternative_route = _dijkstra(origin, destination, EDGES, accessible_only=True)
    alternative = _route_summary(alternative_route, "Accessible alternative") if alternative_route else recommended
    return {
        "origin": origin, "destination": destination,
        "original": delayed,
        "recommended": alternative,
        "warning": {
            "title": "Simulated delay alert",
            "message": "A 12-minute delay has been added for demonstration. Check the alternative route before travelling.",
            "delay_minutes": 12
        },
        "time_saved": delayed["minutes"] - alternative["minutes"],
        "data_label": "Sample demonstration data"
    }
