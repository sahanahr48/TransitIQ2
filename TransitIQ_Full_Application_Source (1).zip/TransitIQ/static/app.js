const $ = (id) => document.getElementById(id);
let map, routeLayer;
const stopCoords = {
  "Central Station": [12.9716, 77.5946],
  "Interchange": [12.9780, 77.6050],
  "Market Square": [12.9650, 77.5860],
  "City Hospital": [12.9900, 77.6200],
  "College Road": [12.9560, 77.6100]
};

function toast(message) {
  const el = $("toast"); el.textContent = message; el.classList.add("show");
  setTimeout(() => el.classList.remove("show"), 2600);
}
async function api(url, options={}) {
  const response = await fetch(url, {headers: {"Content-Type":"application/json"}, ...options});
  const data = await response.json();
  if (!response.ok) throw new Error(data.error || "Something went wrong.");
  return data;
}
function switchTab(name) {
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === name));
  document.querySelectorAll(".panel").forEach(p => p.classList.toggle("active", p.id === name));
  if (name === "buses") loadBuses();
  if (name === "crowd") loadCrowd();
  if (name === "access") loadAccessibility();
  if (name === "journey" && map) setTimeout(() => map.invalidateSize(), 100);
}
document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => switchTab(b.dataset.tab)));

async function loadStops() {
  const stops = await api("/api/stops");
  ["origin","destination"].forEach(id => {
    $(id).innerHTML = stops.map(s => `<option value="${s.name}">${s.name}</option>`).join("");
  });
  $("origin").value = "Central Station"; $("destination").value = "City Hospital";
}
function drawRoute(route) {
  if (!map || !route) return;
  if (routeLayer) map.removeLayer(routeLayer);
  const coords = (route.stops || []).map(s => stopCoords[s]).filter(Boolean);
  if (coords.length) {
    routeLayer = L.polyline(coords, {color:"#2457d6",weight:5,opacity:.85}).addTo(map);
    map.fitBounds(routeLayer.getBounds(), {padding:[35,35]});
  }
}
function routeCard(route, recommended=false) {
  return `<article class="route-card ${recommended?"recommended":""}">
    <div class="route-top"><strong>${route.label}</strong><span class="tag">${recommended?"RECOMMENDED":"ORIGINAL"}</span></div>
    <div class="route-stats"><div><b>${route.minutes} min</b><small>Estimated time</small></div><div><b>${route.transfers}</b><small>Transfers</small></div></div>
    <div class="legs">${route.legs.map(l=>`<span class="leg">${l.bus}: ${l.from} → ${l.to}</span>`).join("")}</div>
  </article>`;
}
function showResults(data, isDelay=false) {
  $("results").classList.remove("hidden");
  $("alertBox").classList.toggle("hidden", !data.warning);
  if (data.warning) $("alertBox").innerHTML = `<strong>⚠ ${data.warning.title}</strong><br>${data.warning.message}`;
  const original = data.original || data.recommended;
  const recommended = data.recommended;
  $("routeCards").innerHTML = (data.original ? routeCard(original,false) : "") + routeCard(recommended,true) +
    `<p class="muted small">${data.data_label || ""}${isDelay && data.time_saved >= 0 ? ` · Alternative saves approximately ${data.time_saved} minutes.`:""}</p>`;
  drawRoute(recommended);
}
async function findRoutes() {
  try {
    const data = await api("/api/plan", {method:"POST",body:JSON.stringify({
      origin:$("origin").value,destination:$("destination").value,
      accessible_only:$("accessibleOnly").checked
    })});
    showResults(data);
  } catch(e) { toast(e.message); }
}
$("findRoute").addEventListener("click", findRoutes);
$("simulateDelay").addEventListener("click", async () => {
  try {
    const data = await api("/api/simulate-delay", {method:"POST",body:JSON.stringify({origin:$("origin").value,destination:$("destination").value})});
    showResults(data,true); loadNotificationCount(); toast("Delay simulation completed.");
  } catch(e) { toast(e.message); }
});

async function loadBuses() {
  try {
    const data = await api("/api/buses");
    $("busList").innerHTML = data.items.map(b=>`<article class="bus-card"><div><strong>${b.bus_id}</strong><small>To ${b.destination}</small><br><span class="status">${b.status}</span></div><div class="arrival">${b.arrival_in} min</div></article>`).join("");
    $("updatedAt").textContent = `Information last updated: ${new Date(data.updated_at).toLocaleTimeString()} · ${data.data_label}`;
  } catch(e) { toast(e.message); }
}
$("refreshBuses").addEventListener("click", loadBuses);

$("crowdForm").addEventListener("submit", async (event) => {
  event.preventDefault();
  const level = document.querySelector('input[name="crowdLevel"]:checked')?.value;
  try {
    const data = await api("/api/crowd", {method:"POST",body:JSON.stringify({
      bus_id:$("crowdBus").value,crowd_level:level,note:$("crowdNote").value
    })});
    $("crowdMessage").textContent = data.message;
    $("crowdForm").reset(); loadCrowd();
  } catch(e) { $("crowdMessage").textContent = e.message; }
});
async function loadCrowd() {
  try {
    const reports = await api("/api/crowd");
    $("crowdReports").innerHTML = reports.length ? reports.map(r=>`<article class="bus-card"><div><strong>${r.bus_id} · ${r.crowd_level} crowd</strong><small>${r.note || "No additional note"}</small></div><small>${new Date(r.created_at).toLocaleString()}</small></article>`).join("") : '<p class="muted small">No crowd reports yet. Be the first to submit one.</p>';
  } catch(e) { toast(e.message); }
}
async function loadAccessibility() {
  try {
    const items = await api("/api/accessibility");
    $("accessList").innerHTML = items.map(a=>`<article class="access-card"><div><strong>${a.route}</strong><small>${a.notes}</small><div class="access-items"><span class="access-chip">Wheelchair: ${a.wheelchair?"Yes":"Not available"}</span><span class="access-chip">Step-free: ${a.step_free?"Yes":"No"}</span><span class="access-chip">Audio info: ${a.audio_info?"Yes":"Not confirmed"}</span></div></div></article>`).join("");
  } catch(e) { toast(e.message); }
}
async function loadNotifications() {
  const items = await api("/api/notifications");
  $("notificationList").innerHTML = items.length ? items.map(n=>`<div class="notification"><strong>${n.title}</strong>${n.message}<div class="small-note">${new Date(n.created_at).toLocaleString()}</div></div>`).join("") : '<p class="muted small">No notifications yet. Try the delay simulation.</p>';
  $("notificationCount").textContent = items.filter(n=>!n.is_read).length;
}
async function loadNotificationCount() {
  try { const items = await api("/api/notifications"); $("notificationCount").textContent = items.filter(n=>!n.is_read).length; } catch(e) {}
}
$("notificationButton").addEventListener("click", async () => {
  $("notificationDrawer").classList.toggle("hidden");
  if (!$("notificationDrawer").classList.contains("hidden")) {
    await loadNotifications();
    await api("/api/notifications/read",{method:"POST",body:"{}"});
    $("notificationCount").textContent = "0";
  }
});
$("closeNotifications").addEventListener("click", ()=>$("notificationDrawer").classList.add("hidden"));

function initMap() {
  if (!window.L) { $("map").innerHTML = "Map library could not load. Check your internet connection."; return; }
  map = L.map("map").setView([12.974,77.601],13);
  L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", {attribution:'&copy; OpenStreetMap contributors'}).addTo(map);
  Object.entries(stopCoords).forEach(([name,coords])=>L.marker(coords).addTo(map).bindPopup(name));
}
(async function init() {
  try {
    await loadStops(); initMap(); await findRoutes(); await loadNotificationCount();
  } catch(e) { toast(e.message); }
  if ("serviceWorker" in navigator) navigator.serviceWorker.register("/static/sw.js").catch(()=>{});
})();
